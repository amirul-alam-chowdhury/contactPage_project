import RightTopElements from "../RightTopElements/RightTopElements";
import style from './Right.module.css'



const RightTopDiv = () => {
  return (
    <div className={style.right_top}>
     <RightTopElements/>
        
      
    </div>
  );
}

export default RightTopDiv
